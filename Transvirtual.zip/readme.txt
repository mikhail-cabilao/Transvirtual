Read Me

*********************************************

Run the executable file requirements:
- Install .NET8 Runtime (link: https://dotnet.microsoft.com/en-us/download/dotnet/8.0 )

Instructions:

1. Unzip the Consignment file
2. Open Consignment folder
3. Run the Consignment.exe file
4. Check the console logs to see the operations (Same directory of consignment.exe you can see a Logs folder when you can see the log file too).
5. consingnment.pdf should be found in same directory if PdfLabels from the response is not empty.

Run the project solution requirements:
- Install Visual Studio 2022
- Install.NET8 SDK if not present (link: https://dotnet.microsoft.com/en-us/download/dotnet/8.0 )

Instructions:

1. Unzip the Project file
2. Open Consignment folder
3. Click the Consignment.csproj
4. Press BUILD or press ( Cltr + Shift + B )
5. Press Run or press ( Cltr + f5 )
6. Console window will popup and see the logs

