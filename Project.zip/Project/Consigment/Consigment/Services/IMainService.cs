﻿namespace Consignment.Services
{
    public interface IMainService
    {
        Task RunAsync();
    }
}