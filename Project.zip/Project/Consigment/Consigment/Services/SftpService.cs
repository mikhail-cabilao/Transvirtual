﻿using Consignment.Models.Configs;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Renci.SshNet;
using System.Xml;

namespace Consignment.Services
{
    public class SftpService : ISftpService
    {
        private readonly SftpConfig _sftpConfig;
        private readonly ILogger<SftpService> _logger;

        public SftpService(IOptions<SftpConfig> sftpConfig, ILogger<SftpService> logger)
        {
            _sftpConfig = sftpConfig.Value;
            _logger = logger;
        }

        public async Task<XmlDocument> LoadXmlFromSftpAsync()
        {
            var xmlDocument = new XmlDocument();

            await Task.Run(() =>
            {
                using (var sftp = new SftpClient(_sftpConfig.SftpHost, _sftpConfig.SftpPort, _sftpConfig.SftpUsername, _sftpConfig.SftpPassword))
                {
                    try
                    {
                        sftp.Connect();
                        _logger.LogInformation("Connected to SFTP server.");

                        // Download the file directly to a memory stream
                        using (var ms = new MemoryStream())
                        {
                            sftp.DownloadFile("Consignment.xml", ms);
                            ms.Position = 0; // Reset stream position to beginning

                            // Load the XML data from the memory stream
                            xmlDocument.Load(ms);
                        }

                        sftp.Disconnect();
                        _logger.LogInformation("Disconnected from SFTP server.");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Error loading XML from SFTP: {message}", ex.Message);
                    }
                }
            });

            return xmlDocument;
        }
    }
}
