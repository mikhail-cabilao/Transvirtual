﻿
namespace Consignment.Services
{
    public interface IConsignmentService
    {
        Task ExecuteAsync();
    }
}