﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Consignment.Services
{
    public class MainService : IHostedService
    {
        private readonly IConsignmentService _consignmentService;
        private readonly ILogger<MainService> _logger;

        public MainService(IConsignmentService consignmentService, ILogger<MainService> logger)
        {
            _consignmentService = consignmentService;
            _logger = logger;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Application start.");

            await _consignmentService.ExecuteAsync();

            Console.ReadKey();
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation("Application start.");

            return Task.CompletedTask;
        }
    }
}
