﻿using AutoMapper;
using Consignment.Extensions;
using Consignment.Helpers;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace Consignment.Services
{
    public class ConsignmentService : IConsignmentService
    {
        private readonly ISftpService _sftpService;
        private readonly ILogger<ConsignmentService> _logger;
        private readonly IMapper _mapper;
        private readonly HttpClient _httpClient;

        public ConsignmentService(
            ISftpService sftpService, 
            ILogger<ConsignmentService> logger,
            IHttpClientFactory httpClientFactory,
            IMapper mapper)
        {
            _sftpService = sftpService;
            _logger = logger;
            _mapper = mapper;
            _httpClient = httpClientFactory.CreateClient("ConsignmentClient");
        }

        public async Task ExecuteAsync()
        {
            try
            {
                var document = await _sftpService.LoadXmlFromSftpAsync();
                var request = _mapper.Map<Models.Requests.ConsignmentRequest>(document.Deserialize<Models.Xml.Consignment>());

                RowMapperHelper.Create(request, document.Deserialize<Models.Xml.Consignment>());

                var stringContent = new StringContent(JsonSerializer.Serialize(request));

                _logger.LogInformation("Start requesting to consignment api");

                var response = await _httpClient.PostAsync("consignment", stringContent);
                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Successfully get response from the consignment api");

                    var result = await response.Content.ReadAsStringAsync();
                    var consignmentResponse = JsonSerializer.Deserialize<Models.Responses.ConsignmentResponse>(result);

                    if (consignmentResponse!.StatusCode != 200) 
                    {
                        _logger.LogError("Error response from consignment api: TransactionId: {transactionId}, StatusCode: {statusCode}, Error: {message}", 
                            consignmentResponse.TransactionID, 
                            consignmentResponse.StatusCode, 
                            consignmentResponse!.StatusText);

                        return;
                    }

                    _logger.LogInformation("Successfully get response from consignment api.");

                    var hasPdfBase64String = false;
                    if (!string.IsNullOrWhiteSpace(consignmentResponse.Data.PdfLabels))
                    {
                        _logger.LogInformation("Pdf Labels saving to local drive.");

                        hasPdfBase64String = true;
                        PdfHelper.Save(consignmentResponse.Data.PdfLabels);
                    }

                    if (!string.IsNullOrWhiteSpace(consignmentResponse.Data.PdfConsignment))
                    {
                        _logger.LogInformation("Pdf Consignment saving to local drive.");

                        hasPdfBase64String = true;
                        PdfHelper.Save(consignmentResponse.Data.PdfConsignment);
                    }

                    if (!hasPdfBase64String)
                    {
                        _logger.LogInformation("PdfLabels and PdfConsignment both empty.");
                    }
                } 
                else
                {
                    _logger.LogInformation("Failed to get response from consignment api");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Encounter an error during processing request. Error: {message}", ex.Message);
            }
        }
    }
}
