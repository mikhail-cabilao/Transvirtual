﻿using System.Xml;

namespace Consignment.Services
{
    public interface ISftpService
    {
        Task<XmlDocument> LoadXmlFromSftpAsync();
    }
}