﻿using Consignment.Models.Requests;
using System.Reflection;

namespace Consignment.Helpers
{
    public static class RowMapperHelper
    {
        public static void Create(Models.Requests.ConsignmentRequest destination, Models.Xml.Consignment source)
        {
            destination.Rows ??= [];

            var rowCount = 1;
            var rowListByGroup = new List<IGrouping<string, PropertyInfo>>();

            // This will create a list by number of row count from the xml payload.
            // e.g Row1Qty, Row2Qty etc. and will be group by row with count.
            while (source.GetType().GetProperties().Any(d => d.Name.StartsWith($"Row{rowCount}")))
            {
                rowListByGroup.Add(GroupPropertiesByPrefix(source.GetType(), $"Row{rowCount}")!);
                rowCount++;
            }

            foreach (var group in rowListByGroup)
            {
                var row = new Row();

                foreach (var rowItem in group)
                {
                    var prop = row.GetType().GetProperty(rowItem.Name.Replace("Row1", ""));

                    // update the new instance of row value from the source
                    prop?.SetValue(row, rowItem.GetValue(source));

                    if (rowItem.Name.StartsWith("Row1Barcode"))
                    {
                        row.Items ??= [];
                        var item = new Item();
                        var itemProp = item.GetType().GetProperty("Barcode");

                        // set barcode property value
                        itemProp!.SetValue(item, rowItem.GetValue(source));

                        // add barcode in the list items.
                        row.Items.Add(item);
                    }
                }

                destination.Rows.Add(row);
            }
        }

        public static IGrouping<string, PropertyInfo> GroupPropertiesByPrefix(Type type, string prefix)
        {
            return type.GetProperties(BindingFlags.Public | BindingFlags.Instance)
                       .Where(p => p.Name.StartsWith(prefix))
                       .GroupBy(p => prefix)
                       .First();
        }
    }
}
