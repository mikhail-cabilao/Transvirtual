﻿namespace Consignment.Helpers
{
    public static class PdfHelper
    {
        public static void Save(string base64)
        {
            byte[] pdfBytes = Convert.FromBase64String(base64);

            try
            {
                File.WriteAllBytes(@"C:\Transvirtual\consignment.pdf", pdfBytes);
            }
            catch
            {
                // if writing to c drive gave you access denied
                // then save it in the executing assembly directory.
                File.WriteAllBytes("consignment.pdf", pdfBytes);
            }
        }
    }
}
