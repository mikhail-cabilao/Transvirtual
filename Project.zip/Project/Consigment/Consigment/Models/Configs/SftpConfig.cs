﻿namespace Consignment.Models.Configs
{
    public class SftpConfig
    {
        public string SftpHost { get; set; }
        public int SftpPort { get; set; }
        public string SftpUsername { get; set; }
        public string SftpPassword { get; set; }
    }
}
