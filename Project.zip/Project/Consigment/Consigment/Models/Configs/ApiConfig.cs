﻿namespace Consignment.Models.Configs
{
    public class ApiConfig
    {
        public string BaseUrlApi { get; set; }
        public string AuthorizationCode { get; set; }
    }
}
