﻿using System.Xml.Serialization;

namespace Consignment.Models.Xml
{
    [XmlRoot(ElementName = "Consignment")]
    public class Consignment
    {

        [XmlElement(ElementName = "UniqueId")]
        public string UniqueId { get; set; }

        [XmlElement(ElementName = "Number")]
        public string Number { get; set; }

        [XmlElement(ElementName = "Date")]
        public DateTime Date { get; set; }

        [XmlElement(ElementName = "CustomerCode")]
        public string CustomerCode { get; set; }

        [XmlElement(ElementName = "SenderDetails")]
        public SenderDetail SenderDetails { get; set; }

        [XmlElement(ElementName = "ConsignmentPickupSpecialInstructions")]
        public string ConsignmentPickupSpecialInstructions { get; set; }

        [XmlElement(ElementName = "ConsignmentSenderIsResidential")]
        public bool ConsignmentSenderIsResidential { get; set; }

        [XmlElement(ElementName = "ReceiverDetails")]
        public ReceiverDetail ReceiverDetails { get; set; }

        [XmlElement(ElementName = "PickupRequest")]
        public bool PickupRequest { get; set; }

        [XmlElement(ElementName = "ReceiverIsResidential")]
        public bool ReceiverIsResidential { get; set; }

        [XmlElement(ElementName = "ReturnPdfLabels")]
        public bool ReturnPdfLabels { get; set; }

        [XmlElement(ElementName = "ReturnPdfConsignment")]
        public bool ReturnPdfConsignment { get; set; }

        [XmlElement(ElementName = "SpecialInstructions")]
        public string SpecialInstructions { get; set; }

        [XmlElement(ElementName = "ConsignmentOtherReferences")]
        public string ConsignmentOtherReferences { get; set; }

        [XmlElement(ElementName = "ConsignmentOtherReferences2")]
        public string ConsignmentOtherReferences2 { get; set; }

        [XmlElement(ElementName = "Row_1_Reference")]
        public string Row1Reference { get; set; }

        [XmlElement(ElementName = "Row_1_Qty")]
        public int Row1Qty { get; set; }

        [XmlElement(ElementName = "Row_1_Description")]
        public string Row1Description { get; set; }

        [XmlElement(ElementName = "Row_1_ItemContentsDescription")]
        public string Row1ItemContentsDescription { get; set; }

        [XmlElement(ElementName = "Row_1_Weight")]
        public int Row1Weight { get; set; }

        [XmlElement(ElementName = "Row_1_Width")]
        public decimal Row1Width { get; set; }

        [XmlElement(ElementName = "Row_1_Length")]
        public decimal Row1Length { get; set; }

        [XmlElement(ElementName = "Row_1_Height")]
        public decimal Row1Height { get; set; }

        [XmlElement(ElementName = "Row_1_DangerousGoodsUNNumber")]
        public string Row1DangerousGoodsUNNumber { get; set; }

        [XmlElement(ElementName = "Row_1_DangerousGoodsClass")]
        public string Row1DangerousGoodsClass { get; set; }

        [XmlElement(ElementName = "Row_1_DangerousGoodsSubRisk")]
        public string Row1DangerousGoodsSubRisk { get; set; }

        [XmlElement(ElementName = "Row_1_DangerousGoodsPackagingGroup")]
        public string Row1DangerousGoodsPackagingGroup { get; set; }

        [XmlElement(ElementName = "Row_1_Barcode_1")]
        public string Row1Barcode1 { get; set; }

        [XmlElement(ElementName = "Row_1_Barcode_2")]
        public string Row1Barcode2 { get; set; }

        [XmlElement(ElementName = "Row_1_Barcode_3")]
        public string Row1Barcode3 { get; set; }

        [XmlElement(ElementName = "Row_1_Barcode_4")]
        public string Row1Barcode4 { get; set; }
    }
}
