﻿namespace Consignment.Models.Responses
{
    public class ConsignmentResponse
    {
        public long TransactionID { get; set; }
        public Data Data { get; set; }
        public int StatusCode { get; set; }
        public string StatusText { get; set; }
    }

    public class Data
    {
        public string Id { get; set; }
        public string PdfLabels { get; set; }
        public string PdfConsignment { get; set; }
        public string ConsignmentNumber { get; set; }
        public List<string> ItemScanValues { get; set; }
    }
}
