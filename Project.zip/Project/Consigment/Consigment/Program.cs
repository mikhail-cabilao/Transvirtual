﻿using Consignment.Extensions;
using Consignment.Models.Configs;
using Consignment.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using System.Reflection;

namespace Consignment
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            var builder = Host.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((context, config) =>
                {
                    config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
                })
                .ConfigureServices((context, services) =>
                {
                    services.AddHostedService<MainService>();
                    services.AddAutoMapper(Assembly.GetExecutingAssembly());

                    services.Configure<ApiConfig>(context.Configuration.GetSection("ApiConfig"));
                    services.Configure<SftpConfig>(context.Configuration.GetSection("SftpConfig"));

                    services.AddSingleton<ISftpService, SftpService>();
                    services.AddSingleton<IConsignmentService, ConsignmentService>();

                    var config = services.BuildServiceProvider().GetRequiredService<IOptions<ApiConfig>>().Value;

                    services.AddHttpClient("ConsignmentClient", client =>
                    {
                        client.BaseAddress = new Uri(config.BaseUrlApi);
                        client.DefaultRequestHeaders.Add("Accept", "application/json");
                        client.DefaultRequestHeaders.Add("Authorization", config.AuthorizationCode);
                    });
                });

            builder.AddSerilog();

            await builder.Build().StartAsync();
        }
    }
}
