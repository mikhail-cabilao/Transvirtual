﻿using AutoMapper;

namespace Consignment.AutoMapper
{
    public class ConsignmentProfile : Profile
    {
        public ConsignmentProfile()
        {
            CreateMap<Models.Xml.Consignment, Models.Requests.ConsignmentRequest>()
                // Sender Mapping
                .ForMember(des => des.SenderName, opt => opt.MapFrom(src => src.SenderDetails.Name))
                .ForMember(des => des.SenderEmail, opt => opt.MapFrom(src => src.SenderDetails.Email))
                .ForMember(des => des.SenderPostcode, opt => opt.MapFrom(src => src.SenderDetails.Postcode))
                .ForMember(des => des.SenderAddress, opt => opt.MapFrom(src => src.SenderDetails.Address))
                .ForMember(des => des.SenderAddress2, opt => opt.MapFrom(src => src.SenderDetails.Address2))
                .ForMember(des => des.SenderSuburb, opt => opt.MapFrom(src => src.SenderDetails.Suburb))
                .ForMember(des => des.SenderState, opt => opt.MapFrom(src => src.SenderDetails.State))
                .ForMember(des => des.SenderReference, opt => opt.MapFrom(src => src.SenderDetails.Reference))
                .ForMember(des => des.ConsignmentSenderPhone, opt => opt.MapFrom(src => src.SenderDetails.Phone))
                .ForMember(des => des.ConsignmentSenderContact, opt => opt.MapFrom(src => src.SenderDetails.Contact))
                .ForMember(des => des.SenderReference, opt => opt.MapFrom(src => src.SenderDetails.Reference))
                // Receiver Mapping
                .ForMember(des => des.ReceiverName, opt => opt.MapFrom(src => src.ReceiverDetails.Name))
                .ForMember(des => des.ReceiverEmail, opt => opt.MapFrom(src => src.ReceiverDetails.Email))
                .ForMember(des => des.ReceiverPostcode, opt => opt.MapFrom(src => src.ReceiverDetails.Postcode))
                .ForMember(des => des.ReceiverAddress, opt => opt.MapFrom(src => src.ReceiverDetails.Address))
                .ForMember(des => des.ReceiverAddress2, opt => opt.MapFrom(src => src.ReceiverDetails.Address2))
                .ForMember(des => des.ReceiverSuburb, opt => opt.MapFrom(src => src.ReceiverDetails.Suburb))
                .ForMember(des => des.ReceiverState, opt => opt.MapFrom(src => src.ReceiverDetails.State))
                .ForMember(des => des.ConsignmentReceiverPhone, opt => opt.MapFrom(src => src.ReceiverDetails.Phone))
                .ForMember(des => des.ConsignmentReceiverContact, opt => opt.MapFrom(src => src.ReceiverDetails.Contact));
        }
    }
}
