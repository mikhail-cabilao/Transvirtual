﻿using System.Xml;
using System.Xml.Serialization;

namespace Consignment.Extensions
{
    public static class XmlDocumentExtensions
    {
        public static T Deserialize<T>(this XmlDocument document) where T: class
        {
            using (var reader = new StringReader(document.OuterXml))
            {
                var serializer = new XmlSerializer(typeof(T));
                return (T)serializer.Deserialize(reader)!;
            }
        }
    }
}
