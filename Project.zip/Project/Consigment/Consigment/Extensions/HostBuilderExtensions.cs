﻿using Microsoft.Extensions.Hosting;
using Serilog;

namespace Consignment.Extensions
{
    public static class HostBuilderExtensions
    {
        public static void AddSerilog(this IHostBuilder builder)
        {
            Log.Logger = new LoggerConfiguration()
                   .MinimumLevel.Information()
                   .WriteTo.Console()
                   .WriteTo.File(
                       path: "Logs/log-.txt",
                       rollingInterval: RollingInterval.Day,
                       outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level}] {Message}{NewLine}{Exception}")
                   .CreateLogger();

            builder.UseSerilog();
        }
    }
}
